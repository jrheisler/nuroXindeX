class Stream {
  constructor(initial) {
    this.value = initial;
    this.subscribers = [];
  }

  subscribe(fn) {
    this.subscribers.push(fn);
    fn(this.value);
  }

  set(val) {
    this.value = val;
    this.subscribers.forEach(fn => fn(val));
  }

  get() {
    return this.value;
  }
}