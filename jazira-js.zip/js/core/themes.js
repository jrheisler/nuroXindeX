const themes = {
  light: {
    background: '#fff',
    foreground: '#111',
    accent: '#007acc'
  },
  dark: {
    background: '#111',
    foreground: '#fff',
    accent: '#66f'
  }
};
